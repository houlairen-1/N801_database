% setup
stego_subdirs=g_stego_subdirs_for_downsample;
payload_subdirs=g_payload_subdirs_for_downsample;

for db_idx=1:length(g_db_subdirs)
    original_root=fullfile(g_images_root, ...
                           g_db_subdirs{db_idx}, ...
                           g_original_subdir_for_downsample);
    downsample_root=fullfile(g_images_root, ...
                             g_db_subdirs{db_idx}, ...
                             g_downsample_subdir_for_downsample);

    % preparement. create all the target directories
    downsample_dir=fullfile(downsample_root, ...
                           g_cover_subdir);
    if ~exist(downsample_dir,'dir')
        mkdir(downsample_dir);
        fileattrib(downsample_dir,'+w','a');
    end
    for stego_idx=1:length(stego_subdirs)
        for payload_idx=1:length(payload_subdirs)
            downsample_dir=fullfile(downsample_root, ...
                                   stego_subdirs{stego_idx}, ...
                                   payload_subdirs{payload_idx});
            if ~exist(downsample_dir,'dir')
                mkdir(downsample_dir);
                fileattrib(downsample_dir,'+w','a');
            end
        end
    end
    
    original_list=dir(fullfile(original_root,g_cover_subdir, ...
                               '*.pgm'));
    limit=numel(original_list);
    % num_per_slave=ceil(limit/g_slave_count);
    % % bypass the images not assigned to this slave
    % min_idx=(g_slave_no-1)*num_per_slave+1;
    % max_idx=min(limit,g_slave_no*num_per_slave);

    parfor i=1:limit%min_idx:max_idx
        img=imread(fullfile(original_root, ...
                            g_cover_subdir, ...
                            original_list(i).name));
        img_downsample=f_downsample_sublattices(img,g_downsample_type);
        imwrite(img_downsample, fullfile(downsample_root, ...
                                        g_cover_subdir, ...
                                        original_list(i).name));
    end    

    for stego_idx=1:length(stego_subdirs)
        for payload_idx=1:length(payload_subdirs)
            original_list= ...
                dir(fullfile(original_root, ...
                             stego_subdirs{stego_idx}, ...
                             payload_subdirs{payload_idx}, ...
                             '*.pgm'));
            limit=numel(original_list);
            % num_per_slave=ceil(limit/g_slave_count);
            % % bypass the images not assigned to this slave
            % min_idx=(g_slave_no-1)*num_per_slave+1;
            % max_idx=min(limit,g_slave_no*num_per_slave);
            parfor i=1:limit%min_idx:max_idx
                img=imread(fullfile(original_root, ...
                                    stego_subdirs{stego_idx}, ...
                                    payload_subdirs{payload_idx}, ...
                                    original_list(i).name));
                img_downsample=f_downsample_sublattices(img,g_downsample_type);
                imwrite(img_downsample, ...
                        fullfile(downsample_root, ...
                                 stego_subdirs{stego_idx}, ...
                                 payload_subdirs{payload_idx}, ...
                                 original_list(i).name));
            end    
        end
    end
    
end
