function tutorial()
% -------------------------------------------------------------------------
% Linear Classification using LSMR | November 2015 | version 1.0 | TUTORIAL
% -------------------------------------------------------------------------
% Copyright (c) 2015 DDE Lab, Binghamton University, NY.
% Copyright (c) 2015 LM2S Lab, Troyes Univ. of Technology, FR.
% All Rights Reserved.
% -------------------------------------------------------------------------
% Contact: vsedigh1@binghamton.edu 
%          remi.cogranne@utt.fr
%          fridrich@binghamton.edu
%          Tomas.Pevny@agents.fel.cvut.cz
%          http://dde.binghamton.edu/download/LCLSMR
% -------------------------------------------------------------------------
clc;clear all;close all;
% Short tutorial for the linear classifier using LSMR solver developed for 
% steganalysis in digital images.

% Load prepared cover/stego features. These features correspond to CC-PEV
% features extracted from nsF5 steganography at payload 0.2 bpac. Used JPEG
% quality factor = 75.
cover = load('example/cover.mat');
stego = load('example/stego.mat');

% Both loaded structures contain fields 'F' and 'names'. F is a feature
% matrix with individual samples in rows and individual features in
% columns, i.e., the number of columns corresponds to the feautre-space
% dimensionality. Field 'names' contains image filenames of the
% corresponding cover (or stego) images. Note that this format is
% consistent with the previous version of our ensemble implementation.

% As you can notice, filenames in cover.names and stego.names are
% de-synchronized. Furthermore, there is 2000 cover features but only 1994
% stego features. This simulates the real-life scenario where (for many
% steganographic methods) embedding may fail for some images and/or the
% features were extracted from images in a different order. Synchronization
% of cover/stego feature pairs (more details about this in the next
% paragraph) is an important pre-processing step in steganalysis and thus
% is part of this tutorial as well.  

% In steganalysis, it is important to train on the *pairs* of
% cover-features and the corresponding stego-features. When dividing the
% features into training/testing parts, for example, these pairs need to be
% preserved. But it is equally important to keep track of these pairs even
% within the training set itself! This is because when splitting the
% training data for the purposes of cross-validation (or bootstrapping),
% these pairs, again, need to be preserved. Therefore, our implementation
% of the ensemble training accepts only two *synchronized* matrices of
% features (cover & stego). While the implementation checks for the sizes
% of both matrices, the actual synchronization is the responsibility of a
% user. See the code below as an example of how to do this correctly.

% Restriction only to images that have both cover and stego features (only
% those will be considered)
names = intersect(cover.names,stego.names);
names = sort(names);

% Prepare cover features C
cover_names = cover.names(ismember(cover.names,names));
[cover_names,ix] = sort(cover_names);
C = cover.F(ismember(cover.names,names),:);
C = C(ix,:);

% Prepare stego features S
stego_names = stego.names(ismember(stego.names,names));
[stego_names,ix] = sort(stego_names);
S = stego.F(ismember(stego.names,names),:);
S = S(ix,:);

% At this point, we have the cover features C and the corresponding
% stego features S. They are correctly synchronized, i.e., the i-th row of
% the  stego matrix S comes from the stego image that was created from the
% cover image with features in the i-th row of the cover matrix C.

% Finally we remove all of the constants features over the whole dataset
D=size(C,2);
varC = var(C,1);
remove = false(1,D);
adepts = unique([find(C(1,:)==C(2,:)) find(S(1,:)==S(2,:))]);
for ad_id = adepts
    U1=unique(C(:,ad_id));
    if numel(U1)==1
        U2=unique(S(:,ad_id));
        if numel(U2)==1, if U1==U2, remove(ad_id) = true; end; end
    end
end
% and also check for NaN values (may occur when the feature value is 
% constant over images)
nan_values = (isnan(varC))>0;
remove = nan_values | remove;
C = C(:,~remove);
S = S(:,~remove);
clear varC;

% Now we can prepare a training set and a testing set. 

% PRNG initialization with seed 1
Matlabversion = version('-release');
Matlabversion = str2num(Matlabversion(1:end-1));
if (Matlabversion>=2012)
    RandStream.setGlobalStream(RandStream('mt19937ar','Seed',1));
else
    RandStream.setDefaultStream(RandStream('mt19937ar','Seed',1));
end

% Division into training/testing set (half/half & preserving pairs)
random_permutation = randperm(size(C,1));
training_set = random_permutation(1:round(size(C,1)/2));
testing_set = random_permutation(round(size(C,1)/2)+1:end);
training_names = names(training_set);
testing_names = names(testing_set);

% Prepare training features
TRN_cover = C(training_set,:);
TRN_stego = S(training_set,:);

% Prepare testing features
TST_cover = C(testing_set,:);
TST_stego = S(testing_set,:);

% Train and Test using the linear classifier with all default settings
[ Results ] = LCLSMR ( TRN_cover, TRN_stego, TST_cover, TST_stego, true);

% ROC curve can be obtained using the following code
figure;grid on;hold on;
plot(Results.PFA, 1-Results.PMD)
xlabel('P_{FA}');
ylabel('P_D');
title(sprintf('P_E = %.4f',Results.PE))
[~ , Ind] = min((Results.PFA + Results.PMD)/2);
plot(Results.PFA(Ind),1-Results.PMD(Ind),'or')
 
% That's pretty much it. For reporting steganalysis results, it is a good
% habit to repeat the experiment several times (for example 10 times) for
% different training/testing splits.
end
