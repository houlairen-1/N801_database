%tic;

% setup, initialization
s_setup;

% global open matlabpool
% if ~(matlabpool('size'))%     matlabpool open local 12;
% end
%pool=parpool(200);
% % generate stego images
if b_generate_stego_images==true
    s_generate_stego_images_8slaves;
    %f_locks(g_locks_dir,'generate_stego_images', ...
    %       g_slave_count,g_slave_no);
    disp('generate_stego_images. DONE!');
end

% % rearrange them
% % if b_rearrange==true
% %     pause(60); %不要太快，适用于一些小样本的场景
% %     s_rearrange_sublattices_8slaves;
% %     f_locks(g_locks_dir,'rearrange_sublattices', ...
% %             g_slave_count,g_slave_no);
% %     disp('rearrange_sublattices. DONE!');
% % end
% % 
% downsample them
if b_downsample==true
    %pause(60); %不要太快，适用于一些小样本的场景
    s_downsample_sublattices_8slaves;
    %f_locks(g_locks_dir,'downsample_sublattices', ...
    %       g_slave_count,g_slave_no);
    disp('downsample_sublattices. DONE!');
end

% generate corresponding features
if b_generate_features==true
    %pause(60); %不要太快，适用于一些小样本的场景
    s_generate_features_8slaves;
    %f_locks(g_locks_dir,'generate_features', ...
    %       g_slave_count,g_slave_no);
    disp('generate_features. DONE!');
end

% 后面的已经不需要matlabpool
% matlabpool不能和ensemble放在一起，否则会有内存不足的错误
%delete(pool);

% collect features
if b_collect_features==true
    %pause(60); %不要太快，适用于一些小样本的场景
    s_collect_features_8slaves;
    % f_locks(g_locks_dir,'collect_features', ...
    %       g_slave_count,g_slave_no);
    disp('collect_features. DONE!');
end

% combine features
if b_combine_features==true
    %pause(60); %不要太快，适用于一些小样本的场景
    s_combine_features_8slaves;
    %f_locks(g_locks_dir,'combine_features', ...
    %       g_slave_count,g_slave_no);
    disp('combine_features. DONE!');
end

% classify
if b_classify==true
    %pause(60); %不要太快，适用于一些小样本的场景
    s_ensemble2_8slaves;
    %f_locks(g_locks_dir,'classify', ...
    %       g_slave_count,g_slave_no);
    disp('classify. DONE!');
end

disp('DONE!');

%t=toc;
%disp(['Time for s_all_in_one: ', num2str(t/3600), ' hours.']);
