function stego=hugo(cover,payload)
    [dir,name,ext]=fileparts(mfilename('fullpath'));
    cover_temp_dir=fullfile(dir,'cover_temp');
    if ~exist(cover_temp_dir)
        mkdir(cover_temp_dir)
    end
    stego_temp_dir=fullfile(dir,'stego_temp');
    if ~exist(stego_temp_dir)
        mkdir(stego_temp_dir)
    end
    
    cover_temp_name=[DataHash(cover) '.pgm'];
    cover_temp_path=fullfile(cover_temp_dir,cover_temp_name);
    imwrite(cover,cover_temp_path);
    unix([fullfile(dir,'hugo_simulator') ' -i ' ...
          cover_temp_path ' -O ' stego_temp_dir ...
          ' -a ' num2str(payload)]);
    
    stego_temp_path=fullfile(stego_temp_dir,cover_temp_name);
    stego=imread(stego_temp_path);

    % remove all temp files
    delete(cover_temp_path);
    delete(stego_temp_path);
end