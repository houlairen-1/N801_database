function y = D_zhj( s, rho )
%变成统计8个
indices=[1 2; 2 1; 2 3; 3 2];
%v是所乘的参数
v=1/9;
diff=0;
%indices = [ 1 2; 2 1; 2 3; 3 2 ];
for i = 1:size(indices,1)
    %s1 = s( 2, 2 );
    diff = diff+s( indices(i,1), indices(i,2) );
end
if s(2,2)==-1 
    if diff<=-1 
        y=rho(2,2)*v;
    else
        y=rho(2,2);
    end

elseif s(2,2)==1 
    if diff>=1
        y=rho(2,2)*v;
    else
        y=rho(2,2);
    end
else
    y=0;
end
% if (diff==1 || diff ==-1)
%     rho(2,2)=rho(2,2)*v;
% end
    %decide the coordinate remove or store 
    %label=labels(i);
    
%     r1 = rho( 2, 2 );
%     r2 = rho( indices(i,1), indices(i,2) );
%     A = ( r1 + r2 ) / 2;
%     
%     if     s1 == -1
%         if     s2 == -1 
%             if(label==true);y=y+0;else;y=y+A;end
%         elseif s2 ==  0
%             if(label==true);y=y+A;else;y=y+A;end
%         else
%             if(label==true);y=y+v*A;else;y=y+A;end
%         end
%         
%     elseif s1 ==  0
%         if     s2 == -1
%             if(label==true);y=y+A;else;y=y+A;end
%         elseif s2 ==  0
%             if(label==true);y=y+0;else;y=y+A;end
%         else
%             if(label==true);y=y+A;else;y=y+A;end
%         end
%     else
%         if     s2 == -1
%             if(label==true);y=y+v*A;else;y=y+A;end
%         elseif s2 ==  0
%             if(label==true);y=y+A;else;y=y+A;end
%         else
%             if(label==true);y=y+0;else;y=y+A;end
%         end
%     end
end

