clc;
clear all;
%read the downsample image
cover=imread('./10000.pgm');
cost=MiPOD(cover);