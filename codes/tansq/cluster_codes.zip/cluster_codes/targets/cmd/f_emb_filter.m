function [stegoB] = f_emb_filter(cover, rho, payload, params)
wetCost = 10^10;
%% Get embedding costs
% inicialization
cover = double(cover);
% p = params.p;
seed = params.seed; %% seed for location selection
rhoP1 = rho;
rhoM1 = rho;
rhoP1(cover==255) = wetCost; % do not embed +1 if the pixel has max value
rhoM1(cover==0) = wetCost; % do not embed -1 if the pixel has min value
stegoB = f_EmbeddingSimulator_seed(cover, rhoP1, rhoM1, floor(payload*numel(cover)), seed);


