function [Fstego] = f_related_embed_MiPOD(cover,row_block,col_block,part_payload,params)
cover=double(cover);
stego=cover;%首先将携密图像等于载体图像
[k,l]=size(cover);
trans_stego=zeros(k+2,l+2);%为了处理边界而做的填充处理
trans_cover=zeros(k+2,l+2);
trans_stego(2:end-1,2:end-1)=stego;
trans_cover(2:end-1,2:end-1)=cover;
idex=1;
for i=1:row_block
     if idex==1           
          for j=1:col_block
               all_cost=f_cal_cost_MiPOD(stego);               
               part_cost=all_cost(i:row_block:end,j:col_block:end);%取出部分cost值
               part_cover=cover(i:row_block:end,j:col_block:end);%取出载体图像的部分
               params.seed=(i-1)*col_block+j;
               if (i==1 && j==1)
                   part_stego = f_emb_filter(part_cover,part_cost,part_payload, params);%部分嵌入
                   stego(i:row_block:end,j:col_block:end)=part_stego; %更新图像  
                   trans_stego(1+i:row_block:end-1,1+j:col_block:end-1)=part_stego;%
               else
                   change=f_cla_diff_fromNeighbor(trans_stego,trans_cover,i,j,row_block,col_block);
                   part_stego = f_emb_filter2(part_cover,change,part_cost,part_payload,params);%部分嵌入
                   stego(i:row_block:end,j:col_block:end)=part_stego; %更新图像   
                   trans_stego(1+i:row_block:end-1,1+j:col_block:end-1)=part_stego;
               end
           end
           idex=0;
       else
           j=col_block;
           while (j>0)
               params.seed=(i-1)*col_block+j;
               all_cost=f_cal_cost_MiPOD(stego);                            
               part_cost=all_cost(i:row_block:end,j:col_block:end);%取出部分cost值
               part_cover=cover(i:row_block:end,j:col_block:end);%取出载体图像当前用于嵌入的部分
               change=f_cla_diff_fromNeighbor(trans_stego,trans_cover,i,j,row_block,col_block);
               part_stego = f_emb_filter2(part_cover,change,part_cost,part_payload, params);%部分嵌入
               stego(i:row_block:end,j:col_block:end)=part_stego; %更新图像 
               trans_stego(1+i:row_block:end-1,1+j:col_block:end-1)=part_stego;
               j=j-1;
           end
           idex=1;
      end
end
 Fstego=stego;

