function [stegoB] = f_emb_filter2(cover,pixel_change, rho, payload, params)
wetCost = 10^10;
%% Get embedding costs
% inicialization
cover = double(cover);
seed = params.seed; %% seed for location selection
rhoP1 = rho;
rhoM1 = rho;
rhoP1(cover==255) = wetCost; % do not embed +1 if the pixel has max value
rhoM1(cover==0) = wetCost; % do not embed -1 if the pixel has min value
rhoP1(pixel_change==1)=(rhoP1(pixel_change==1))./params.w;
rhoM1(pixel_change==-1)=((rhoM1(pixel_change==-1)))./params.w;
stegoB = f_EmbeddingSimulator_seed(cover, rhoP1, rhoM1, floor(payload*numel(cover)), seed);

