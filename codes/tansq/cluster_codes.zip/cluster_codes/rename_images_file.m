clc;
clear all;
cover_path='../BOSS_bilinear_rename';
file=dir(fullfile(cover_path,'*.pgm'));
cover_rename_path='../images/bossbase/original/cover/';
% if ~exist(cover_rename_path,'dir')
%     mkdir(cover_rename_path);
% end

for i=1:length(file)
    cover=imread(fullfile(cover_path,file(i).name));
    imwrite(uint8(cover),[cover_rename_path,file(i).name]);
end
