% 同步锁，确保8个节点在每一次执行完一个脚本后同步。不打算使用parallel
% computing toolbox，尽可能的使代码简单。
% slave_no为1的节点永远充当master。
function f_locks(locks_dir,lock_name,slave_count,slave_no)
    if slave_no==1 %master
        % 删除所有的master lock file
        delete(fullfile(locks_dir,'*_master.lock'));
        disp('all master lock files are deleted');

        b_wait=true;
        while (b_wait)
            % 每10秒检查一次
            pause(10);
            b_wait=false;
            % 只要有一个lock file不存在，就继续循环
            for i=2:slave_count
                lock_file=fullfile(locks_dir, ...
                                   [lock_name '_' num2str(i) ...
                                    '.lock']);
                if ~exist(lock_file,'file')
                    b_wait=true;
                    break;
                end
            end
        end
        % 到了这里所有的slave machines都完成任务了。
        master_lock_file=fullfile(locks_dir, ...
                                  [lock_name '_master.lock']);
        unix(['touch ' master_lock_file]);
        disp([master_lock_file ' is touched']);
    else % slaves
        slave_lock_file= ...
            fullfile(locks_dir, ...
                     [lock_name '_' num2str(slave_no) '.lock']);
        unix(['touch ' slave_lock_file]);
        disp([slave_lock_file ' is touched']);
        master_lock_file=fullfile(locks_dir, ...
                                  [lock_name '_master.lock']);
        b_wait=true;
        while (b_wait)
            % 每10秒检查一次
            pause(10);
            b_wait=false;
            % master仍未生成master.lock，则等待
            if ~exist(master_lock_file)
                b_wait=true;
            end
        end
        % master.lock出现了，则继续往下走
        % 删除对应的slave_lock_file
        delete(slave_lock_file);
        disp([slave_lock_file ' is deleted']);
    end
end