#!/bin/bash

#加载环境变量
PATH=/usr/local/bin/:/usr/local/sbin/:/usr/bin:/usr/sbin:/bin
export PATH

#显示当前目录下的所有文件
cd ../logs/maxsrmd2
for file in $(ls)
do
sed -n '16p' $file >>../g_feature_params_result
done

#*{'bossbase_original_cover vs. bossbase_original_stego_cmd_hill','bossbase_original_cover vs. bossbase_original_stego_hill','bossbase_original_cover vs. bossbase_original_stego_synch_hill','bossbase_original_downsample_minmaxrearr_combined1_cover vs. bossbase_original_downsample_minmaxrearr_combined1_stego_cmd_hill','bossbase_original_downsample_minmaxrearr_combined1_cover vs. bossbase_original_downsample_minmaxrearr_combined1_stego_hill','bossbase_original_downsample_minmaxrearr_combined1_cover vs. bossbase_original_downsample_minmaxrearr_combined1_stego_synch_hill'}*#
#进行结果的重排
cd ..
i=1
for name in {'bossbase_original_cover vs. bossbase_original_stego_cmd_hill','bossbase_original_cover vs. bossbase_original_stego_hill','bossbase_original_cover vs. bossbase_original_stego_synch_hill','bossbase_original_downsample_minmaxrearr_combined1_cover vs. bossbase_original_downsample_minmaxrearr_combined1_stego_cmd_hill','bossbase_original_downsample_minmaxrearr_combined1_cover vs. bossbase_original_downsample_minmaxrearr_combined1_stego_hill','bossbase_original_downsample_minmaxrearr_combined1_cover vs. bossbase_original_downsample_minmaxrearr_combined1_stego_synch_hill'}
do
echo $name >>total_result_maxsrmd2
let j=i*5-4
let k=i*5 
sed -n $j,$k'p' 'g_feature_params_result' | awk 'BEGIN {FS=" "} {printf"%s ",$7}' >>total_result_maxsrmd2
sed -n $j,$k'p' 'g_feature_params_result' | awk 'BEGIN {FS=" "} {printf"%s ",$9}' >>total_result_maxsrmd2
let i=i+1
done
rm g_feature_params_result
