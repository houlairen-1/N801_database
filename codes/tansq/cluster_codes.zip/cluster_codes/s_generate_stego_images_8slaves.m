% setup 
class_subdirs=g_class_subdirs_for_stego_generation;
stego_subdirs=g_stego_subdirs_for_stego_generation;
payload_subdirs=g_payload_subdirs_for_stego_generation;
corresponding_payloads=g_corresponding_payloads_for_stego_generation;


% preparement. create all the target directories
for db_idx=1:length(g_db_subdirs)
    for class_idx=1:length(class_subdirs)
        for stego_idx=1:length(stego_subdirs)
            for payload_idx=1:length(payload_subdirs)
                stego_dir=fullfile(g_images_root, ...
                                   g_db_subdirs{db_idx}, ...
                                   class_subdirs{class_idx}, ...
                                   stego_subdirs{stego_idx}, ...
                                   payload_subdirs{payload_idx});
                if ~exist(stego_dir,'dir')
                    mkdir(stego_dir);
                    fileattrib(stego_dir,'+w','a');
                end
            end
        end
    end
end

for db_idx=1:length(g_db_subdirs)
    for class_idx=1:length(class_subdirs)
        cover_dir=fullfile(g_images_root, ...
                           g_db_subdirs{db_idx}, ...
                           class_subdirs{class_idx}, ...
                           g_cover_subdir);
        cover_list=dir(fullfile(cover_dir,'*.pgm'));
        limit=numel(cover_list);
        % num_per_slave=ceil(limit/g_slave_count);
        % % bypass the images not assigned to this slave
        % min_idx=(g_slave_no-1)*num_per_slave+1;
        % max_idx=min(limit,g_slave_no*num_per_slave);

        parfor cover_idx=1:limit%min_idx:max_idx
            cover=imread(fullfile(cover_dir,cover_list(cover_idx).name));
            for stego_idx=1:length(stego_subdirs)
                for payload_idx=1:length(payload_subdirs)
                    stego_dir=fullfile(g_images_root, ...
                                       g_db_subdirs{db_idx}, ...
                                       class_subdirs{class_idx}, ...
                                       stego_subdirs{stego_idx}, ...
                                       payload_subdirs{payload_idx});
                    if exist(fullfile(stego_dir, ...
                                      cover_list(cover_idx).name),'file')
                        disp([cover_list(cover_idx).name,' is exist!']);
                        continue;
                    end
                    payload=corresponding_payloads(payload_idx);
                    stego=f_generate_stego_image(cover,payload, ...
                                                 stego_subdirs{stego_idx},...
                                                 g_generate_stego_images_specific_params);
                    imwrite(stego ,fullfile(stego_dir,cover_list(cover_idx).name));        
                end
            end
        end
    end
end
