function f_collect_slaves_features(features_root,features_name)
    % 如果features生成过，那就直接bypass可以了。
    features_path= ...
        fullfile(features_root,[features_name '.mat']);
    if exist(features_path)
        fprintf('%s exists, bypass!!!\n',[features_name '.mat']);
        return;
    end

    features_temp_dir=fullfile(features_root, ...
                               [features_name '_temp']);
    if ~exist(features_temp_dir)
        fprintf('%s does not exist, fatal error!\n', ...
                features_temp_dir);
        return;
    end
    features_temp_list=dir(fullfile(features_temp_dir,'*.mat'));
    F=[];
    names={};

    for i=1:numel(features_temp_list)
        features_temp_namespace=load(fullfile(features_temp_dir, ...
                                         features_temp_list(i).name));
        F=[F; features_temp_namespace.F];
        names=[names; ...
               reshape(features_temp_namespace.names, ...
                       length(features_temp_namespace.names),1)];
    end
    save(fullfile(features_root,[features_name '.mat']), ...
         'F','names','-v7.3');

    % remove features_temp_dir
    rmdir(features_temp_dir,'s');
end