function stego=f_generate_stego_image(cover,payload,stego_type,g_generate_stego_images_specific_params)
    switch (stego_type)
      case 'stego_hill'
        cover_rho = HILL( cover );
        cost = imfilter( cover_rho, 0.4/2*[0 1 0; 1 4 1; 0 1 0], 'conv', ...
                         'symmetric' );
        rhoM1 = cost; rhoM1( cover ==   0 ) = 10^10;
        rho0  = zeros( size( cost ) );
        rhoP1 = cost; rhoP1( cover == 255 ) = 10^10;
        stego = uint8( EmbeddingSimulator( cover, rhoM1, rho0, rhoP1, ...
                                                 payload ) );
      case 'stego_synch_hill'
        cover_rho = HILL( cover );
        cost = imfilter( cover_rho, 0.4/2*[0 1 0; 1 4 1; 0 1 0], 'conv', ...
                         'symmetric' );
        rhoM1 = cost; rhoM1( cover ==   0 ) = 10^10;
        rho0  = zeros( size( cost ) );
        rhoP1 = cost; rhoP1( cover == 255 ) = 10^10;
        stego_start = uint8( EmbeddingSimulator( cover, rhoM1, rho0, rhoP1, ...
                                                 payload ) );
        sweeps = g_generate_stego_images_specific_params.sweep_times;
        [stego_all, distortion_all, costs_all, lambda_all, grid] = ...
            Gibbs( cover, cover_rho, stego_start, sweeps, payload );
        stego=stego_all(:,:,sweeps+1);
      case 'stego_cmd_hill'
        params.w=9;
        params.H=0;
        r_block=4; c_block=4;
        sweeps = g_generate_stego_images_specific_params.sweep_times;
        stego=f_embedding_message_hill(cover,r_block,c_block,payload, ...
                                       params,sweeps);
       % stego=uint8(stego);
      
      case 'stego_suniward'
        cover_rho = SUNI( cover );
        cost = imfilter( cover_rho, 0.4/2*[0 1 0; 1 4 1; 0 1 0], 'conv', ...
                         'symmetric' );
        rhoM1 = cost; rhoM1( cover ==   0 ) = 10^10;
        rho0  = zeros( size( cost ) );
        rhoP1 = cost; rhoP1( cover == 255 ) = 10^10;
        stego = uint8( EmbeddingSimulator( cover, rhoM1, rho0, rhoP1, ...
                                                 payload ) );
      case 'stego_synch_suniward'
        cover_rho = SUNI( cover );
        cost = imfilter( cover_rho, 0.4/2*[0 1 0; 1 4 1; 0 1 0], 'conv', ...
                         'symmetric' );
        rhoM1 = cost; rhoM1( cover ==   0 ) = 10^10;
        rho0  = zeros( size( cost ) );
        rhoP1 = cost; rhoP1( cover == 255 ) = 10^10;
        stego_start = uint8( EmbeddingSimulator( cover, rhoM1, rho0, rhoP1, ...
                                                 payload ) );
        sweeps = g_generate_stego_images_specific_params.sweep_times;
        [stego_all, distortion_all, costs_all, lambda_all, grid] = ...
            Gibbs( cover, cover_rho, stego_start, sweeps, payload );
        stego=stego_all(:,:,2);
      case 'stego_cmd_suniward'
        params.w=9;
        params.H=0;
        r_block=2; c_block=2;
        
        stego=f_embedding_message_suniward(cover,r_block,c_block,payload, ...
                                           params);
        stego=uint8(stego);
      case 'stego_hugo'
        stego=hugo(cover,payload);
        
      case 'stego_MiPOD'
        stego=MiPOD_ori(cover,payload);
        stego=uint8(stego);
        
      case 'stego_synch_MiPOD'
        cover_rho = MiPOD( cover );
        cost = imfilter( cover_rho, 0.4/2*[0 1 0; 1 4 1; 0 1 0], 'conv', ...
                         'symmetric' );
        rhoM1 = cost; rhoM1( cover ==   0 ) = 10^10;
        rho0  = zeros( size( cost ) );
        rhoP1 = cost; rhoP1( cover == 255 ) = 10^10;
        stego_start = uint8( EmbeddingSimulator( cover, rhoM1, rho0, rhoP1, ...
                                                 payload ) );
        sweeps = g_generate_stego_images_specific_params.sweep_times;
        [stego_all, distortion_all, costs_all, lambda_all, grid] = ...
            Gibbs( cover, cover_rho, stego_start, sweeps, payload );
        stego=stego_all(:,:,sweeps+1);
        
      case 'stego_cmd_MiPOD'
        params.w=9;
        params.H=0;
        r_block=4; c_block=4;
        sweeps = g_generate_stego_images_specific_params.sweep_times;
        stego=f_embedding_message_MiPOD(cover,r_block,c_block,payload, ...
                                       params);
        stego=uint8(stego);
    end
end
