clear; clc;

% targets path
addpath('../targets/synch');
addpath('../targets/synch/costs')
addpath('../targets/synch/costs/MiPOD')
addpath('../targets/synch/distortion')
addpath('../targets/synch/embedding')
addpath('../targets/cmd');
addpath('../targets/hugo');
addpath('../targets/MiPOD_ori');

% tools path
addpath('../tools');
addpath('../tools/srm');
addpath('../tools/maxsrmd2');
addpath('../tools/ensemble2');
addpath('../tools/LinearClassifier_1.0');

% for slave machines
g_slave_count=16;
% get slave no
[status,cmdout]= ...
    unix('hostname | sed -n ''s/.*-0-\([0-9]*\)\..*/\1/p'''); 
g_slave_no=str2num(cmdout);

% root paths
g_total_root='/home/zhanghaojie/parpool_anti_synch';
g_images_root=[g_total_root '/images'];
g_features_root=[g_total_root '/features'];
g_logs_root=[g_total_root '/logs'];

% synchronization locks
%g_locks_dir=[g_total_root '/locks'];

% for images and features hierarchies
% bossbase database
%g_db_subdirs={'bossbase'};
% 一万幅imagenet 1024x1024图像
%g_db_subdirs={'fall11_whole_1024x1024_10000'};
% 1024x1024，从bossbase raw转化而来
g_db_subdirs={'bossbase'};
g_cover_subdir='cover';
g_feature_subdirs={'maxsrmd2'};

% by default, all the switches are set to false,
% we will set each one of them to true specifically
b_generate_stego_images=true;
b_rearrange=true;
b_downsample=true;
b_generate_features=true;
b_collect_features=true;
b_combine_features=true;
b_classify=true;

% stego_generation
g_generate_stego_images_specific_params.sweep_times=1;

b_generate_stego_images=false;
g_class_subdirs_for_stego_generation={'original'};
g_stego_subdirs_for_stego_generation={'stego_hill','stego_synch_hill','stego_cmd_hill'};
g_payload_subdirs_for_stego_generation={'10','20','30','40','50'};
g_corresponding_payloads_for_stego_generation=[0.1,0.2,0.3,0.4,0.5];

% rearrange
% $$$ b_rearrange=true;
% $$$ g_original_subdir_for_rearrange='original';
% $$$ g_rearrange_subdir_for_rearrange='rearrange';
% $$$ g_stego_subdirs_for_rearrange={'stego_synch_hill'};
% $$$ g_payload_subdirs_for_rearrange={'30'};

% downsample
b_downsample=false;
% 目前看来性能最好是minmaxrearr
g_downsample_type='minmaxrearr';
g_original_subdir_for_downsample='original';
g_downsample_subdir_for_downsample=['downsample_' g_downsample_type];
g_stego_subdirs_for_downsample={'stego_hill','stego_synch_hill','stego_cmd_hill'};
g_payload_subdirs_for_downsample={'10','20','30','40','50'};

% original+rearrange+downsample，性能不如original+minmaxrearr好
% $$$ g_class_subdirs_default_after_recompose{1}='original';
% $$$ g_class_subdirs_default_after_recompose{2}='rearrange';
% $$$ g_class_subdirs_default_after_recompose{3}=['downsample_' g_downsample_type];

% original+minmaxrearr downsample
g_class_subdirs_default_after_recompose{1}='original';
g_class_subdirs_default_after_recompose{2}=['downsample_' g_downsample_type];

% features extraction
b_generate_features=false;

% for maxsrmd2
g_feature_specific_params.maxsrmd2_payload=0.5;

g_class_subdirs_for_features_extraction= ...
    g_class_subdirs_default_after_recompose;
g_stego_subdirs_for_features_extraction={'stego_hill','stego_synch_hill','stego_cmd_hill'};
g_payload_subdirs_for_features_extraction={'10','20','30','40','50'};

% features collection
b_collect_features=false;

% features combinationx
b_combine_features=false;
g_class_subdirs_to_combine= ...
    g_class_subdirs_default_after_recompose;
g_stego_subdirs_for_features_combination={'stego_hill','stego_synch_hill','stego_cmd_hill'};
g_payload_subdirs_for_features_combination={'10','20','30','40','50'};
% combined1, 最普通的拼接方式。
recompose_type=g_class_subdirs_to_combine{1};
for i=2:length(g_class_subdirs_to_combine)
    recompose_type= ...
        [recompose_type '_' g_class_subdirs_to_combine{i}];
end
g_combine_type=[recompose_type '_combined1'];
%g_combine_type=g_class_subdirs_to_combine{2};
% classify
b_classify=true;
g_class_subdirs_for_classification={'original'};%{g_combine_type};%{'original',g_combine_type};
g_stego_subdirs_for_classification={'stego_hill'};
g_payload_subdirs_for_classification={'10'};
classfier_class='ensemble';