function f_generate_features(img_dir,features_root,feature_type,features_name,num_imgs_per_cycle,feature_specific_params)
    features_dir=fullfile(features_root,feature_type);
    % 如果features生成过，那就直接bypass可以了。
    features_path= ...
        fullfile(features_dir,[features_name '.mat']);
    if exist(features_path)
        fprintf('%s exists, bypass!!!\n',[features_name '.mat']);
        return;
    end
    
    features_temp_dir=fullfile(features_dir, ...
                               [features_name '_temp']);
    %features_temp_slave_dir=fullfile(features_dir, ...
    %                                [features_name '_temp_' '_1']);
    
    if ~exist(features_temp_dir)
        mkdir(features_temp_dir);
        fileattrib(features_temp_dir,'+w','a');
    end

    % if ~exist(features_temp_slave_dir)
    %     mkdir(features_temp_slave_dir);
    % end

    img_list=dir(fullfile(img_dir,'*.pgm'));
    
    limit=numel(img_list);
    % num_per_slave=ceil(limit/slave_count);
    % % bypass the images not assigned to this slave
    % min_idx=(slave_no-1)*num_per_slave+1;
    % max_idx=min(limit,slave_no*num_per_slave);
    
    ImageSet={};
    names={};
    imageset_collection={};
    names_collection={};
    collection_counter=1;
    j=1;
    for i=1:limit%min_idx:max_idx
        if (mod(j,num_imgs_per_cycle)==1 && ~isempty(ImageSet)) ...
                || i==limit%i==max_idx
            if i==limit%max_idx
                names{j}=img_list(i).name;            
                ImageSet{j}=fullfile(img_dir,img_list(i).name);
            end

            imageset_collection{collection_counter}=ImageSet;
            names_collection{collection_counter}=names;
            collection_counter=collection_counter+1;
            
            ImageSet={};
            names={};
            j=1;
        end
        
        if i<limit%max_idx
            names{j}=img_list(i).name;            
            ImageSet{j}=fullfile(img_dir,img_list(i).name);
            j=j+1;
        end
    end

    parfor i=1:length(imageset_collection)
        features_temp_path= ...
            fullfile(features_temp_dir, ...
                     [features_name '_' num2str(i) '.mat']);
        if exist(features_temp_path,'file')~=2
            ImageSet=imageset_collection{i};
            names=names_collection{i};
            
            F=f_generate_specific_features(ImageSet,feature_type, ...
                                           feature_specific_params);
            f_parsave_f_names(features_temp_path,F,names);
        end
    end
    
    % features_temp_list=dir(fullfile(features_temp_slave_dir, ...
    %                                 '*.mat'));
    % F=[];
    % names={};
    % for i=1:numel(features_temp_list)
    %     features_temp_namespace=load(fullfile(features_temp_slave_dir, ...
    %                                           features_temp_list(i).name));
    %     F=[F; features_temp_namespace.F];
    %     names=[names; ...
    %            reshape(features_temp_namespace.names, ...
    %                    length(features_temp_namespace.names),1)];
    % end
    
    % features_for_this_slave_path=fullfile(features_temp_dir, ...
    %                                       [features_name '_slave_' ...
    %                     num2str(slave_no) '.mat']);
    % save(features_for_this_slave_path,'F','names','-v7.3');
    
    % % remove features_temp_slave_dir
    % rmdir(features_temp_slave_dir,'s'); 
    
end

function F=f_generate_specific_features(ImageSet,feature_type,feature_specific_params)
    F=[];
    switch (feature_type)
      case 'srm'
        features=SRM(ImageSet);
        features_cells=struct2cell(features);
        features_flat=[];
        for j=1:numel(features_cells)
            features_flat=[features_flat features_cells{j}];
        end
        F=features_flat;
      case 'maxsrmd2'
        for img_no=1:length(ImageSet)
            cover=imread(ImageSet{img_no});
            % 随机概率是有问题的。
            %cover_map=rand(size(cover)); 
            % 采用HILL算出来的概率。
            cover_rho = HILL( cover );
            %cost = SUNI( cover );
            %cost=MiPOD(cover);
            cost = imfilter( cover_rho, 0.4/2*[0 1 0; 1 4 1; 0 ...
                                 1 0], 'conv','symmetric' );
            rhoM1 = cost; rhoM1( cover ==   0 ) = 10^10;
            rho0  = zeros( size( cost ) );
            rhoP1 = cost; rhoP1( cover == 255 ) = 10^10;
            % set payload 
            payload=feature_specific_params.maxsrmd2_payload;
            x = double(cover);
            n = numel(x);
            m = payload * n;
            lambda = calc_lambda_ter(rhoM1, rho0, rhoP1, m, n);
            [pChangeM1, pChange0, pChangeP1] = ...
                GetPchange(lambda, rhoM1, rho0, rhoP1); 
            % 也即我认为cover_map是这个像素会被修改的概率。
            cover_map=pChangeM1+pChangeP1;
            fea_flat=[];
            fea=maxSRMd2(cover,cover_map);
            fea_cells=struct2cell(fea);
            for cell_no=1:numel(fea_cells)
                fea_flat=[fea_flat fea_cells{cell_no}];
            end
            F(img_no,:)=fea_flat;
        end
    end
end