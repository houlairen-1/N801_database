function img_rearrange=f_rearrange_sublattices(img)
    img_l1_1=uint8(zeros(size(img)./2));
    img_l1_2=img_l1_1;
    img_l2_1=img_l1_1;
    img_l2_2=img_l1_1;
    img_l1_1=img(1:2:end,2:2:end);
    img_l1_2=img(2:2:end,1:2:end);
    img_l2_1=img(1:2:end,1:2:end);
    img_l2_2=img(2:2:end,2:2:end);

    img_rearrange=[img_l2_1 img_l1_1;img_l1_2 img_l2_2];
end