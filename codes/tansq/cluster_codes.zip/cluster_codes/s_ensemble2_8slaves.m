for fea_idx=1:length(g_feature_subdirs)
    % setup
    log_dir=fullfile(g_logs_root,g_feature_subdirs{fea_idx});
    if ~exist(log_dir)
        mkdir(log_dir);
        fileattrib(log_dir,'+w','a');
    end

    features_dir=fullfile(g_features_root, ...
                          g_feature_subdirs{fea_idx});
    classfier=classfier_class;
    class_subdirs=g_class_subdirs_for_classification;
    stego_subdirs=g_stego_subdirs_for_classification;
    payload_subdirs=g_payload_subdirs_for_classification;
    
    % preparation
    features_pairs={};

    counter=1;
    for db_idx=1:length(g_db_subdirs)
        for class_idx=1:length(class_subdirs)
            cover_features_name=[g_db_subdirs{db_idx} '_' ...
                                class_subdirs{class_idx} '_' ...
                                g_cover_subdir];
            for type_idx=1:length(stego_subdirs)
                for payload_idx=1:length(payload_subdirs)
                    stego_features_name=[g_db_subdirs{db_idx} '_' ...
                                        class_subdirs{class_idx} '_' ...
                                        stego_subdirs{type_idx} '_' ...
                                        payload_subdirs{payload_idx}];
                    features_pairs{counter}= ...
                        {cover_features_name,stego_features_name};
                    counter=counter+1;
                end
            end
        end
    end
    
    limit=numel(features_pairs);
    num_per_slave=ceil(limit/g_slave_count);
    % bypass the pairs not assigned to this slave
    min_idx=(g_slave_no-1)*num_per_slave+1;
    max_idx=min(limit,g_slave_no*num_per_slave);

    % % exceed the end
    % if(min_idx>max_idx)
    %     fprintf('s_ensemble2_8slaves: the min_idx %d exceeds the end.\n', ...
    %             min_idx);
    %     return;
    % end
    % for ensemble, it is no need to use parfor
    for i=min_idx:max_idx%1:limit%min_idx:max_idx%
        f_ensemble2_multiple_times( ...
            fullfile(features_dir,[features_pairs{i}{1} '.mat']), ...
            fullfile(features_dir,[features_pairs{i}{2} '.mat']), ...
            log_dir,classfier,10,0.5);
        fprintf('s_ensemble2_8slaves: %s vs. %s is done.\n', ...
                features_pairs{i}{1},features_pairs{i}{2});
    end
    
end
