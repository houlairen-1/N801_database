% 这个脚本只在master machine上运行
%if g_slave_no==1 %master
    % setup 
class_subdirs=g_class_subdirs_for_features_extraction;
stego_subdirs=g_stego_subdirs_for_features_extraction;
payload_subdirs=g_payload_subdirs_for_features_extraction;

for fea_idx=1:length(g_feature_subdirs)
    features_dir=fullfile(g_features_root, ...
                          g_feature_subdirs{fea_idx});
    for db_idx=1:length(g_db_subdirs)
        for class_idx=1:length(class_subdirs)
            features_name=[g_db_subdirs{db_idx} '_' ...
                           class_subdirs{class_idx} '_' ...
                           g_cover_subdir];
            f_collect_slaves_features(features_dir,features_name);
            for stego_idx=1:length(stego_subdirs)
                for payload_idx=1:length(payload_subdirs)
                    features_name=[g_db_subdirs{db_idx} '_' ...
                                   class_subdirs{class_idx} '_' ...
                                   stego_subdirs{stego_idx} '_' ...
                                   payload_subdirs{payload_idx}];
                    f_collect_slaves_features(features_dir,features_name);
                end
            end
        end
    end
end
    %end