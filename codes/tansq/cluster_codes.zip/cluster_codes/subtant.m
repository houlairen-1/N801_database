function k=subtant(i,j)
    k=i-(j-1)*10000;
end