function f_combine_multiple_features(features_paths,combined_features_path)
    features={};
    features{1}=load(features_paths{1});
    names=features{1}.names;
    for i=2:length(features_paths)
        features{i}=load(features_paths{i});
        names = intersect(names,features{i}.names);
    end
    names = sort(names);

    F=[];
    for i=1:length(features_paths)
        features_names = features{i}.names(ismember(features{i}.names,names));
        [features_names,ix] = sort(features_names);
        F_temp = features{i}.F(ismember(features{i}.names,names),:);
        F_temp = F_temp(ix,:);
        F=[F F_temp];
    end
    save(combined_features_path,'F','names','-v7.3');        
